fx_version 'cerulean'
game 'gta5'

author 'Vest Fix Made by Californialife'
description 'Vest Fix Made by Californialife'
version '1.0.0'

client_script 'client/client.lua'
