local freemodeModels = {
    [`mp_m_freemode_01`] = 'mp_m_freemode_01',
    [`mp_f_freemode_01`] = 'mp_f_freemode_01'
}

local function isFreemodeModel(modelHash)
    return freemodeModels[modelHash] ~= nil
end

local armorEntity = nil

-- Funktion, um die Weste korrekt an den Spieler anzupassen
function ApplyVest()
    local ped = PlayerPedId()
    local pedModelHash = GetEntityModel(ped)
    
    if not isFreemodeModel(pedModelHash) then
        return
    end
    
    local boneIndex = GetPedBoneIndex(ped, 24818)  -- Torso (Knochenindex)
    local armorModel = "prop_armorvest"  -- Weste-Modell (hier kannst du dein Modell eintragen)
    
    -- Lösche bereits existierende Weste (falls vorhanden)
    if DoesEntityExist(armorEntity) then
        DeleteEntity(armorEntity)
    end
    
    -- Erstelle die Weste und platziere sie korrekt am Torso
    armorEntity = CreateObject(GetHashKey(armorModel), 0.0, 0.0, 0.0, true, true, true)
    AttachEntityToEntity(armorEntity, ped, boneIndex, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
end

local savedBlendData, savedFaceFeatures = {}, {}
local isHeadShrunken = false
local lastMaskDrawable, lastMaskTexture = -1, -1

local function loop()
    local ped = PlayerPedId()

    if not DoesEntityExist(ped) then
        return
    end

    -- Überprüfen, ob der Spieler ein Freemode-Modell hat
    local pedModelHash = GetEntityModel(ped)
    if not isFreemodeModel(pedModelHash) then
        return
    end

    -- Weste anwenden, wenn der Spieler ein Freemode-Modell hat
    ApplyVest()
end

CreateThread(function()
    while true do
        loop()
        Wait(200)  -- Alle 200 ms überprüfen
    end
end)
